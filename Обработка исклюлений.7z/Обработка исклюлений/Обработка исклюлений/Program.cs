﻿class MyDate
{
    private int day;
    private int month;
    private int year;

    public int Day
    {
        get { return day; }
        set
        {
            if (value < 1 || value > DaysInMonth(month, year))
            {
                throw new ArgumentOutOfRangeException(nameof(Day), "Day cannot be less than 1 or more than the number of days in a month");
            }
            day = value;
        }
    }

    public int Month
    {
        get { return month; }
        set
        {
            if (value < 1 || value > 12)
            {
                throw new ArgumentOutOfRangeException(nameof(Month), "Month should be from 1 to 12");
            }
            month = value;

            if (day > DaysInMonth(month, year))
            {
                day = DaysInMonth(month, year);
            }
        }
    }

    public int Year
    {
        get { return year; }
        set
        {
            if (value < 1)
            {
                throw new ArgumentOutOfRangeException(nameof(Year), "Year cannot be less than 1");
            }
            year = value;

            if (day > DaysInMonth(month, year))
            {
                day = DaysInMonth(month, year);
            }
        }
    }

    public string Day_Of_Week
    {
        get
        {
            int a = (month < 3) ? month + 12 : month;
            int b = year % 100;
            int c = year / 100;

            int dayOfWeek = (day + (13 * (a + 1)) / 5 + b + (b / 4) + (c / 4) - 2 * c) % 7;

            dayOfWeek = ((dayOfWeek + 6) % 7);
            string dayName;

            switch (dayOfWeek)
            {
                case 0: dayName = "Sunday"; break;
                case 1: dayName = "Monday"; break;
                case 2: dayName = "Tuesday"; break;
                case 3: dayName = "Wednesday"; break;
                case 4: dayName = "Thursday"; break;
                case 5: dayName = "Friday"; break;
                case 6: dayName = "Saturday"; break;
                default: dayName = "Unknown"; break;
            }

            return dayName;
        }
    }

    public MyDate()
    {
        day = 1;
        month = 1;
        year = 2023;
    }

    public MyDate(int day, int month, int year)
    {
        Year = year;
        Month = month;
        Day = day;
    }

    private bool IsLeapYear(int year)
    {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
    }

    public int Difference(MyDate other)
    {
        int totalDays1 = CalculateTotalDays(year, month, day);
        int totalDays2 = CalculateTotalDays(other.year, other.month, other.day);

        return Math.Abs(totalDays1 - totalDays2);
    }

    private int CalculateTotalDays(int year, int month, int day)
    {
        int days = day;

        for (int y = 1; y < year; y++)
            days += IsLeapYear(y) ? 366 : 365;

        for (int m = 1; m < month; m++)
            days += DaysInMonth(m, year);

        return days;
    }

    private int DaysInMonth(int month, int year)
    {
        switch (month)
        {
            case 1: return 31;
            case 2: return IsLeapYear(year) ? 29 : 28;
            case 3: return 31;
            case 4: return 30;
            case 5: return 31;
            case 6: return 30;
            case 7: return 31;
            case 8: return 31;
            case 9: return 30;
            case 10: return 31;
            case 11: return 30;
            case 12: return 31;
            default: return 1;
        }
    }

    public void ChangeDate(int days)
    {
        int totalDays = CalculateTotalDays(year, month, day) + days;

        year = 1;
        while (totalDays >= 365)
        {
            totalDays -= IsLeapYear(year) ? 366 : 365;
            year++;
        }

        month = 1;
        while (totalDays >= DaysInMonth(month, year))
        {
            totalDays -= DaysInMonth(month, year);
            month++;
        }

        day = totalDays;
    }

    public void PrintDate()
    {
        Console.WriteLine($"{day:D2}/{month:D2}/{year}");
    }

    public override string ToString()
    {
        return $"{day:D2}/{month:D2}/{year}";
    }

    public static int operator -(MyDate d1, MyDate d2)
    {
        return d1.Difference(d2);
    }

    public static MyDate operator +(MyDate d, int days)
    {
        MyDate newDate = new MyDate(d.day, d.month, d.year);
        newDate.ChangeDate(days);
        return newDate;
    }

    public static MyDate operator ++(MyDate d)
    {
        MyDate newDate = new MyDate(d.day, d.month, d.year);
        newDate.ChangeDate(1);
        return newDate;
    }

    public static MyDate operator --(MyDate d)
    {
        MyDate newDate = new MyDate(d.day, d.month, d.year);
        newDate.ChangeDate(-1);
        return newDate;
    }

    public static bool operator >(MyDate d1, MyDate d2)
    {
        return d1.CalculateTotalDays(d1.year, d1.month, d1.day) > d2.CalculateTotalDays(d2.year, d2.month, d2.day);
    }

    public static bool operator <(MyDate d1, MyDate d2)
    {
        return d1.CalculateTotalDays(d1.year, d1.month, d1.day) < d2.CalculateTotalDays(d2.year, d2.month, d2.day);
    }

    public static bool operator ==(MyDate d1, MyDate d2)
    {
        return d1.CalculateTotalDays(d1.year, d1.month, d1.day) == d2.CalculateTotalDays(d2.year, d2.month, d2.day);
    }

    public static bool operator !=(MyDate d1, MyDate d2)
    {
        return d1.CalculateTotalDays(d1.year, d1.month, d1.day) != d2.CalculateTotalDays(d2.year, d2.month, d2.day);
    }
}

class Program
{
    static void Main()
    {
        try
        {
            MyDate defaultDate = new MyDate();
            Console.Write("Default date: ");
            defaultDate.PrintDate();

            MyDate customDate = new MyDate(1, 1, 2022);
            Console.Write("Custom date: ");
            customDate.PrintDate();

            Console.WriteLine($"Day of the week: {customDate.Day_Of_Week}");

            int daysDifference = customDate.Difference(defaultDate);
            Console.WriteLine($"Difference in days: {daysDifference}");

            customDate.ChangeDate(29);
            Console.Write("Date after change by 29 days: ");
            customDate.PrintDate();

            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");

            MyDate date1 = new MyDate(5, 5, 2024);
            MyDate date2 = new MyDate(9, 9, 2024);

            Console.WriteLine("Starting dates:");
            date1.PrintDate();
            date2.PrintDate();

            Console.WriteLine($"Difference between dates (date2 - date1): {date2 - date1} days");
            Console.WriteLine($"Add a number to a date (date2 + 5): {date2 + 5} days");

            date1++;
            Console.WriteLine("Date after the operator ++:");
            date1.PrintDate();

            date2--;
            Console.WriteLine("Date after operator --:");
            date2.PrintDate();

            Console.WriteLine($"Is date1 greater than date2? {date1 > date2}");
            Console.WriteLine($"Is date1 less than date2? {date1 < date2}");
            Console.WriteLine($"Are date1 and date2 equal? {date1 == date2}");
            Console.WriteLine($"Are date1 and date2 not equal? {date1 != date2}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
        }
    }
}
